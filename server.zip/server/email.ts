import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: 'smtp.zoho.com',
  port: 587,
  secure: false,
  auth: {
    user: process.env.ZOHO_EMAIL,
    pass: process.env.ZOHO_PASSWORD,
  },
});

export async function sendInquiryNotification(inquiry: {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  propertyAddress: string;
  propertyType: string;
  serviceInterest: string;
  additionalDetails?: string | null;
}) {
  const emailContent = `
New Service Inquiry from Praesidio Management Group Website

Customer Information:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Name: ${inquiry.firstName} ${inquiry.lastName}
Email: ${inquiry.email}
Phone: ${inquiry.phone}

Property Details:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Address: ${inquiry.propertyAddress}
Property Type: ${inquiry.propertyType}
Service Interest: ${inquiry.serviceInterest}

${inquiry.additionalDetails ? `Additional Details:\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n${inquiry.additionalDetails}` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This inquiry was submitted through the Praesidio Management Group website.
Please respond to the customer promptly.
  `.trim();

  const mailOptions = {
    from: `"Praesidio Management Group" <${process.env.ZOHO_EMAIL}>`,
    to: process.env.ZOHO_EMAIL,
    subject: `New Service Inquiry: ${inquiry.serviceInterest} - ${inquiry.firstName} ${inquiry.lastName}`,
    text: emailContent,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9fafb;">
        <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
          <h2 style="color: #1e293b; margin-top: 0; margin-bottom: 24px; font-size: 24px;">
            New Service Inquiry
          </h2>
          
          <div style="background-color: #f1f5f9; border-radius: 6px; padding: 20px; margin-bottom: 20px;">
            <h3 style="color: #475569; margin-top: 0; margin-bottom: 16px; font-size: 16px; font-weight: 600;">Customer Information</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px 0; color: #64748b; font-weight: 600; width: 140px;">Name:</td>
                <td style="padding: 8px 0; color: #1e293b;">${inquiry.firstName} ${inquiry.lastName}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Email:</td>
                <td style="padding: 8px 0; color: #1e293b;"><a href="mailto:${inquiry.email}" style="color: #3b82f6; text-decoration: none;">${inquiry.email}</a></td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Phone:</td>
                <td style="padding: 8px 0; color: #1e293b;"><a href="tel:${inquiry.phone}" style="color: #3b82f6; text-decoration: none;">${inquiry.phone}</a></td>
              </tr>
            </table>
          </div>

          <div style="background-color: #f1f5f9; border-radius: 6px; padding: 20px; margin-bottom: 20px;">
            <h3 style="color: #475569; margin-top: 0; margin-bottom: 16px; font-size: 16px; font-weight: 600;">Property Details</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px 0; color: #64748b; font-weight: 600; width: 140px;">Address:</td>
                <td style="padding: 8px 0; color: #1e293b;">${inquiry.propertyAddress}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Property Type:</td>
                <td style="padding: 8px 0; color: #1e293b;">${inquiry.propertyType}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Service Interest:</td>
                <td style="padding: 8px 0; color: #1e293b;"><strong>${inquiry.serviceInterest}</strong></td>
              </tr>
            </table>
          </div>

          ${inquiry.additionalDetails ? `
          <div style="background-color: #f1f5f9; border-radius: 6px; padding: 20px; margin-bottom: 20px;">
            <h3 style="color: #475569; margin-top: 0; margin-bottom: 12px; font-size: 16px; font-weight: 600;">Additional Details</h3>
            <p style="color: #1e293b; margin: 0; line-height: 1.6;">${inquiry.additionalDetails}</p>
          </div>
          ` : ''}

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0;">
            <p style="color: #64748b; font-size: 14px; margin: 0;">
              This inquiry was submitted through the Praesidio Management Group website. Please respond to the customer promptly.
            </p>
          </div>
        </div>
      </div>
    `,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent successfully:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
}
