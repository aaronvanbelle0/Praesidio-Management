import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import ValueProposition from "@/components/ValueProposition";
import PropertyShowcase from "@/components/PropertyShowcase";
import ServiceArea from "@/components/ServiceArea";
import PricingTiers from "@/components/PricingTiers";
import ServiceGuarantees from "@/components/ServiceGuarantees";
import ContractorVetting from "@/components/ContractorVetting";
import HowItWorks from "@/components/HowItWorks";
import FAQ from "@/components/FAQ";
import IntakeForm from "@/components/IntakeForm";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero />
      <ValueProposition />
      <PropertyShowcase />
      <ServiceArea />
      <PricingTiers />
      <ServiceGuarantees />
      <ContractorVetting />
      <HowItWorks />
      <FAQ />
      <IntakeForm />
      <CTASection />
      <Footer />
    </div>
  );
}
