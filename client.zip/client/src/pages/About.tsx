import { Card } from "@/components/ui/card";
import { Shield, Heart, Clock, Award, MapPin, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function About() {
  const values = [
    {
      icon: Shield,
      title: "Trust & Integrity",
      description: "Every contractor undergoes rigorous background checks and continuous performance reviews. Your home's security is our priority.",
      testId: "trust-integrity"
    },
    {
      icon: Heart,
      title: "White-Glove Service",
      description: "We treat every property with the same care and attention we'd give our own homes. No detail is too small.",
      testId: "white-glove"
    },
    {
      icon: Clock,
      title: "24/7 Availability",
      description: "Home emergencies don't wait for business hours. Our round-the-clock response team ensures you're never alone in a crisis.",
      testId: "availability"
    },
    {
      icon: Award,
      title: "Excellence Standards",
      description: "We partner only with licensed, insured professionals who meet our stringent quality benchmarks and maintain perfect safety records.",
      testId: "excellence"
    }
  ];

  const differentiators = [
    {
      title: "Vetted Professional Network",
      description: "Access to 500+ pre-screened contractors across all trades - plumbing, electrical, HVAC, landscaping, and specialized services.",
      testId: "network"
    },
    {
      title: "Single Point of Contact",
      description: "No more juggling multiple contractors. One dedicated coordinator manages all your property needs, from routine maintenance to emergency repairs.",
      testId: "single-contact"
    },
    {
      title: "Transparent Pricing",
      description: "Clear tier-based pricing with no hidden fees. You'll always know what you're paying for, with detailed invoices and pre-approved cost estimates.",
      testId: "transparent-pricing"
    },
    {
      title: "Proactive Maintenance",
      description: "Seasonal inspections and preventative care plans designed to catch issues before they become expensive emergencies.",
      testId: "proactive"
    },
    {
      title: "Multi-Property Care Made Simple",
      description: "Whether you own one luxury home or multiple properties, we handle all your homes without adding to your workload.",
      testId: "portfolio"
    },
    {
      title: "Pacific Northwest Expertise",
      description: "Deep understanding of regional challenges - from wet winters requiring specialized waterproofing to seismic considerations for coastal properties.",
      testId: "pnw-expertise"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-accent/5 to-background py-20 md:py-32">
        <div className="max-w-6xl mx-auto px-6">
          <div className="max-w-4xl">
            <h1 className="font-serif text-4xl md:text-6xl font-bold text-foreground mb-6" data-testid="text-about-heading">
              Redefining Luxury Home Management
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8" data-testid="text-about-intro">
              Praesidio Management Group was founded on a simple belief: luxury homeowners deserve property care that matches the quality of their investments. We've built a trusted network of verified professionals and a seamless coordination platform to deliver concierge-level service for every aspect of home maintenance.
            </p>
            <div className="flex flex-wrap gap-6 text-sm text-muted-foreground" data-testid="text-about-stats">
              <div className="flex items-center gap-2" data-testid="text-stat-professionals">
                <Users className="w-5 h-5 text-accent" />
                <span>500+ Vetted Professionals</span>
              </div>
              <div className="flex items-center gap-2" data-testid="text-stat-coverage">
                <MapPin className="w-5 h-5 text-accent" />
                <span>King to Whatcom County</span>
              </div>
              <div className="flex items-center gap-2" data-testid="text-stat-licensed">
                <Shield className="w-5 h-5 text-accent" />
                <span>100% Licensed & Insured</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-serif text-3xl md:text-5xl font-bold text-foreground mb-6" data-testid="text-mission-heading">
                Our Mission
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6" data-testid="text-mission-description">
                To provide luxury homeowners with complete peace of mind through trusted, transparent, and expertly coordinated property management services. We bridge the gap between high-end real estate ownership and reliable, vetted professional care.
              </p>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-mission-approach">
                Every homeowner deserves to enjoy their property without the stress of maintenance logistics, contractor sourcing, or emergency coordination. Praesidio handles the complexity so you can focus on what matters - living in and loving your home.
              </p>
            </div>
            <Card className="p-8" data-testid="card-commitment">
              <h3 className="font-serif text-2xl font-semibold text-foreground mb-4" data-testid="text-commitment-heading">
                Our Commitment
              </h3>
              <ul className="space-y-4 text-muted-foreground">
                <li className="flex items-start gap-3" data-testid="text-commitment-response">
                  <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                  <span><strong className="text-foreground">24/7 Response Guarantee:</strong> Emergency calls answered within minutes, on-site service within hours, or your tier fee refunded.</span>
                </li>
                <li className="flex items-start gap-3" data-testid="text-commitment-vetting">
                  <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                  <span><strong className="text-foreground">Rigorous Vetting:</strong> Background checks, licensing verification, and insurance confirmation for every professional in our network.</span>
                </li>
                <li className="flex items-start gap-3" data-testid="text-commitment-transparency">
                  <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                  <span><strong className="text-foreground">Complete Transparency:</strong> Detailed cost breakdowns, pre-approved estimates, and clear billing with no surprise charges.</span>
                </li>
                <li className="flex items-start gap-3" data-testid="text-commitment-quality">
                  <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0"></div>
                  <span><strong className="text-foreground">Quality Assurance:</strong> Every service call is reviewed, rated, and tracked to ensure consistent excellence.</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-5xl font-bold text-foreground mb-4" data-testid="text-values-heading">
              Our Core Values
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto" data-testid="text-values-description">
              The principles that guide every decision we make and every service we deliver
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {values.map((value) => (
              <Card key={value.testId} className="p-8" data-testid={`card-value-${value.testId}`}>
                <div className="flex items-start gap-4">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/20 flex-shrink-0">
                    <value.icon className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-serif text-xl font-semibold text-foreground mb-2" data-testid={`text-value-${value.testId}-title`}>
                      {value.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed" data-testid={`text-value-${value.testId}-description`}>
                      {value.description}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-5xl font-bold text-foreground mb-4" data-testid="text-why-choose-heading">
              Why Choose Praesidio
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto" data-testid="text-why-choose-description">
              What sets us apart in luxury property management
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {differentiators.map((item) => (
              <Card key={item.testId} className="p-6" data-testid={`card-differentiator-${item.testId}`}>
                <h3 className="font-serif text-lg font-semibold text-foreground mb-3" data-testid={`text-differentiator-${item.testId}-title`}>
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed" data-testid={`text-differentiator-${item.testId}-description`}>
                  {item.description}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Service Philosophy */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="max-w-6xl mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-serif text-3xl md:text-5xl font-bold text-foreground mb-8 text-center" data-testid="text-philosophy-heading">
              Our Service Philosophy
            </h2>
            <div className="space-y-8">
              <div>
                <h3 className="font-serif text-2xl font-semibold text-foreground mb-4" data-testid="text-philosophy-prevention-heading">
                  Prevention Over Reaction
                </h3>
                <p className="text-muted-foreground leading-relaxed" data-testid="text-philosophy-prevention-description">
                  The best emergency is the one that never happens. Our preventative maintenance programs identify potential issues before they escalate - from HVAC tune-ups that prevent winter breakdowns to gutter cleaning that protects your foundation. We believe proactive care is both smarter and more cost-effective than reactive repairs.
                </p>
              </div>
              <div>
                <h3 className="font-serif text-2xl font-semibold text-foreground mb-4" data-testid="text-philosophy-relationships-heading">
                  Relationships Built on Trust
                </h3>
                <p className="text-muted-foreground leading-relaxed" data-testid="text-philosophy-relationships-description">
                  We don't just connect you with contractors - we build lasting relationships with the best professionals in the Pacific Northwest. Our contractors know they're serving discerning homeowners who expect excellence, and they rise to meet that standard every time. This mutual respect creates a service experience unlike any other.
                </p>
              </div>
              <div>
                <h3 className="font-serif text-2xl font-semibold text-foreground mb-4" data-testid="text-philosophy-communication-heading">
                  Clear, Consistent Communication
                </h3>
                <p className="text-muted-foreground leading-relaxed" data-testid="text-philosophy-communication-description">
                  You'll never be left wondering about the status of a service request. From the moment you contact us to the final invoice, you receive regular updates, transparent timelines, and direct access to your dedicated coordinator. We believe luxury service means never having to chase down answers.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Area */}
      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-5xl font-bold text-foreground mb-4" data-testid="text-service-area-heading">
              Serving the Pacific Northwest
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8" data-testid="text-service-area-description">
              Comprehensive coverage from King County to Whatcom County, with deep expertise in regional property challenges and seasonal maintenance needs.
            </p>
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-accent/10 rounded-md">
              <MapPin className="w-5 h-5 text-accent" />
              <span className="text-foreground font-medium" data-testid="text-service-area-counties">
                King • Pierce • Snohomish • Skagit • Whatcom Counties
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-accent/5">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-cta-heading">
            Experience the Praesidio Difference
          </h2>
          <p className="text-lg text-muted-foreground mb-8" data-testid="text-cta-description">
            Join discerning homeowners who trust us with their most valuable assets
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link href="/#tiers">
              <Button size="lg" data-testid="button-view-tiers">
                View Service Tiers
              </Button>
            </Link>
            <Link href="/#contact">
              <Button variant="outline" size="lg" data-testid="button-contact">
                Schedule Consultation
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
