import { Shield, Clock, Award } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function ValueProposition() {
  const values = [
    {
      icon: Shield,
      title: "Trust",
      description: "Every professional is thoroughly vetted, background-checked, and licensed. Your home's security is our priority.",
    },
    {
      icon: Clock,
      title: "Convenience",
      description: "24/7 emergency response and seamless coordination. We handle everything so you don't have to.",
    },
    {
      icon: Award,
      title: "Excellence",
      description: "Premium quality service with attention to every detail. Your property deserves nothing less than perfection.",
    },
  ];

  return (
    <section id="services" className="py-24 md:py-32 bg-background">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-4">
            Why Choose Praesidio
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Built on the pillars of trust, convenience, and unwavering excellence
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <Card
              key={index}
              className="p-8 text-center hover-elevate transition-all duration-300"
              data-testid={`card-value-${value.title.toLowerCase()}`}
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/20 mb-6">
                <value.icon className="w-8 h-8 text-accent-foreground" />
              </div>
              <h3 className="font-serif text-2xl font-semibold text-foreground mb-3">
                {value.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {value.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
