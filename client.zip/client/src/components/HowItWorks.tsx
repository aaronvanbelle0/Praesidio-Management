import { Shield, Clock, Wrench } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: Shield,
      number: "01",
      title: "Vetted Professionals",
      description: "All tradesmen undergo rigorous background checks, licensing verification, and quality assessments.",
    },
    {
      icon: Clock,
      number: "02",
      title: "24/7 Availability",
      description: "Round-the-clock emergency response and support. We're always here when you need us.",
    },
    {
      icon: Wrench,
      number: "03",
      title: "Seamless Service",
      description: "From scheduling to completion, we coordinate everything for a hassle-free experience.",
    },
  ];

  return (
    <section id="how-it-works" className="py-24 md:py-32 bg-background">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A simple, three-step process to exceptional home care
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-12 md:gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative text-center"
              data-testid={`step-${index}`}
            >
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-0.5 bg-border" />
              )}
              
              <div className="relative inline-flex items-center justify-center w-24 h-24 rounded-full bg-accent/20 mb-6">
                <step.icon className="w-10 h-10 text-accent-foreground" />
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-accent text-accent-foreground flex items-center justify-center text-sm font-semibold">
                  {step.number}
                </div>
              </div>
              
              <h3 className="font-serif text-2xl font-semibold text-foreground mb-3">
                {step.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
