import { Button } from "@/components/ui/button";
import { Shield, Clock } from "lucide-react";

export default function Hero() {
  const scrollToPricing = () => {
    const element = document.getElementById("pricing");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-background to-muted/30" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-accent/10 via-transparent to-transparent" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-32 md:py-40 text-center">
        <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-semibold text-foreground mb-6 leading-tight">
          Luxury Home Management,
          <br />
          <span className="text-muted-foreground">Redefined</span>
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed">
          Get your time back and eliminate home maintenance stress. 
          Vetted professionals, 24/7 response, and white-glove care that lets you enjoy your home worry-free.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <Button
            size="lg"
            onClick={scrollToPricing}
            className="text-base"
            data-testid="button-hero-explore"
          >
            Explore Services
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={scrollToPricing}
            className="text-base backdrop-blur-sm"
            data-testid="button-hero-contact"
          >
            Schedule Consultation
          </Button>
        </div>

        <div className="flex flex-wrap justify-center gap-8 md:gap-12 text-sm text-muted-foreground">
          <div className="flex items-center gap-2" data-testid="trust-indicator-response">
            <Clock className="w-5 h-5" />
            <span>24/7 Response or Money Back</span>
          </div>
          <div className="flex items-center gap-2" data-testid="trust-indicator-professionals">
            <Shield className="w-5 h-5" />
            <span>Vetted Professionals</span>
          </div>
        </div>
      </div>
    </section>
  );
}
