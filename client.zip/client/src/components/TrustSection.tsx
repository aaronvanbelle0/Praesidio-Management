import tradesmanImage from "@assets/stock_images/professional_tradesm_134e0d90.jpg";

export default function TrustSection() {
  const stats = [
    { number: "500+", label: "Vetted Professionals" },
    { number: "24/7", label: "Availability" },
    { number: "98%", label: "Client Satisfaction" },
    { number: "50+", label: "Properties Managed" },
  ];

  return (
    <section className="py-24 md:py-32 bg-muted/30">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative h-[400px] md:h-[500px] rounded-md overflow-hidden">
            <img
              src={tradesmanImage}
              alt="Professional tradesman providing luxury home service"
              className="w-full h-full object-cover"
              data-testid="img-tradesman"
            />
          </div>

          <div>
            <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-6">
              Built on Trust and Excellence
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              We understand that your home is your sanctuary. That's why every professional 
              in our network is carefully vetted, licensed, and insured. Experience the peace 
              of mind that comes with knowing your property is in expert hands.
            </p>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} data-testid={`stat-${index}`}>
                  <div className="font-serif text-4xl font-bold text-foreground mb-1">
                    {stat.number}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
