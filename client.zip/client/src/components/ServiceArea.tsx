import { MapPin } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function ServiceArea() {
  const counties = [
    "King County",
    "Snohomish County",
    "Pierce County",
    "Kitsap County",
    "Skagit County",
    "Whatcom County"
  ];

  return (
    <section className="py-24 md:py-32 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-4">
            <MapPin className="w-6 h-6 text-accent" />
            <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground" data-testid="text-service-areas-heading">
              Service Areas
            </h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-service-areas-description">
            Proudly serving luxury properties throughout the Pacific Northwest, from King County to Whatcom County
          </p>
        </div>

        <Card className="max-w-4xl mx-auto p-8">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {counties.map((county) => (
              <div
                key={county}
                className="flex items-center gap-3 p-4 rounded-md bg-muted/50"
                data-testid={`service-area-${county.toLowerCase().replace(' ', '-')}`}
              >
                <div className="w-2 h-2 rounded-full bg-accent" />
                <span className="text-foreground font-medium">{county}</span>
              </div>
            ))}
          </div>
          
          <p className="text-center text-sm text-muted-foreground mt-8">
            Not in our service area? Contact us to discuss expanding coverage to your location.
          </p>
        </Card>
      </div>
    </section>
  );
}
