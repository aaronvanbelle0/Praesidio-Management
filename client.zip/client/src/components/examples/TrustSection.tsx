import TrustSection from "../TrustSection";

export default function TrustSectionExample() {
  return <TrustSection />;
}
