import PricingTiers from "../PricingTiers";

export default function PricingTiersExample() {
  return <PricingTiers />;
}
