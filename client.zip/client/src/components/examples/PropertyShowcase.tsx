import PropertyShowcase from "../PropertyShowcase";

export default function PropertyShowcaseExample() {
  return <PropertyShowcase />;
}
