import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQ() {
  const faqs = [
    {
      question: "What is included in the vetting process for professionals?",
      answer: "Every professional undergoes comprehensive background checks, license verification, insurance validation, and reference reviews. We also conduct skills assessments and quality checks to ensure they meet our high standards.",
    },
    {
      question: "How quickly can you respond to emergencies?",
      answer: "Our 24/7 emergency response team is available around the clock. We typically respond to emergency calls within 15 minutes and can dispatch a professional to your property within 2-4 hours, depending on your location and the nature of the emergency.",
    },
    {
      question: "Can I upgrade or downgrade my service tier?",
      answer: "Absolutely! You can change your service tier at any time. When upgrading, the new benefits take effect immediately. When downgrading, changes apply at your next renewal period to ensure you receive the full value of your current plan.",
    },
    {
      question: "Do you service multiple properties?",
      answer: "Yes, our Estate Concierge tier is specifically designed for multi-property management. You'll have a dedicated account manager who coordinates all services across your properties, ensuring consistent quality and keeping you informed without the hassle.",
    },
    {
      question: "What happens if I'm not satisfied with a service?",
      answer: "Your satisfaction is our priority. If you're not completely satisfied with any service, contact your account manager immediately. We'll work to resolve the issue, which may include sending a different professional or providing a full refund for that specific service.",
    },
  ];

  return (
    <section id="faq" className="py-24 md:py-32 bg-background">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground">
            Everything you need to know about our services
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="border rounded-md px-6"
              data-testid={`faq-item-${index}`}
            >
              <AccordionTrigger className="text-left font-medium hover:no-underline">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
