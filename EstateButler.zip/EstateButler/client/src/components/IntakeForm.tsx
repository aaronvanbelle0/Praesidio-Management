import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function IntakeForm() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    propertyAddress: "",
    propertyType: "",
    serviceInterest: "",
    additionalDetails: "",
  });

  const submitInquiry = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/inquiries", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Request Submitted",
        description: "We'll contact you within 24 hours to discuss your property management needs.",
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        propertyAddress: "",
        propertyType: "",
        serviceInterest: "",
        additionalDetails: "",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitInquiry.mutate(formData);
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-24 md:py-32 bg-muted/30">
      <div className="max-w-3xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-4">
            Request Service
          </h2>
          <p className="text-lg text-muted-foreground">
            Tell us about your property and we'll create a customized care plan
          </p>
        </div>

        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => handleChange("firstName", e.target.value)}
                  required
                  data-testid="input-first-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => handleChange("lastName", e.target.value)}
                  required
                  data-testid="input-last-name"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  required
                  data-testid="input-email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                  required
                  data-testid="input-phone"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="propertyAddress">Property Address</Label>
              <Input
                id="propertyAddress"
                value={formData.propertyAddress}
                onChange={(e) => handleChange("propertyAddress", e.target.value)}
                required
                data-testid="input-property-address"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="propertyType">Property Type</Label>
                <Select
                  value={formData.propertyType}
                  onValueChange={(value) => handleChange("propertyType", value)}
                  required
                >
                  <SelectTrigger id="propertyType" data-testid="select-property-type">
                    <SelectValue placeholder="Select property type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single-family">Single Family Home</SelectItem>
                    <SelectItem value="estate">Estate</SelectItem>
                    <SelectItem value="waterfront">Waterfront Property</SelectItem>
                    <SelectItem value="mountain">Mountain Home</SelectItem>
                    <SelectItem value="multi-property">Multiple Properties</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="serviceInterest">Service Tier Interest</Label>
                <Select
                  value={formData.serviceInterest}
                  onValueChange={(value) => handleChange("serviceInterest", value)}
                  required
                >
                  <SelectTrigger id="serviceInterest" data-testid="select-service-tier">
                    <SelectValue placeholder="Select service tier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="executive">Executive Management</SelectItem>
                    <SelectItem value="estate">Estate Concierge</SelectItem>
                    <SelectItem value="consultation">Need Consultation</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="additionalDetails">Additional Details</Label>
              <Textarea
                id="additionalDetails"
                value={formData.additionalDetails}
                onChange={(e) => handleChange("additionalDetails", e.target.value)}
                placeholder="Tell us about any specific needs or concerns..."
                rows={4}
                data-testid="textarea-additional-details"
              />
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full"
              disabled={submitInquiry.isPending}
              data-testid="button-submit-form"
            >
              {submitInquiry.isPending ? "Submitting..." : "Submit Request"}
            </Button>
          </form>
        </Card>
      </div>
    </section>
  );
}
