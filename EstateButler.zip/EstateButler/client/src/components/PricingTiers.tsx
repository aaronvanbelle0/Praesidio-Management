import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";
import { useLocation } from "wouter";

export default function PricingTiers() {
  const [, setLocation] = useLocation();

  const tiers = [
    {
      name: "Executive Management",
      slug: "executive",
      price: "$8,000",
      period: "per year",
      popular: true,
      features: [
        "Full maintenance & vendor coordination",
        "Emergency response coordination",
        "Quarterly complimentary service",
        "Vendor billing management",
      ],
    },
    {
      name: "Estate Concierge",
      slug: "estate",
      price: "$35,000",
      period: "per year",
      popular: false,
      features: [
        "All Executive Management services",
        "24/7 priority response",
        "Dedicated client manager",
        "Six annual complimentary services",
        "Multi-residence coordination",
      ],
    },
  ];

  const handleSelectPlan = (slug: string) => {
    setLocation(`/plans/${slug}`);
  };

  return (
    <section id="pricing" className="py-24 md:py-32 bg-muted/30">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-4">
            Choose Your Service Tier
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Flexible plans designed to meet your unique property management needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {tiers.map((tier, index) => (
            <Card
              key={index}
              className={`p-8 relative hover-elevate transition-all duration-300 ${
                tier.popular ? "border-accent" : ""
              }`}
              data-testid={`card-tier-${tier.name.toLowerCase().replace(/\s+/g, "-")}`}
            >
              {tier.popular && (
                <Badge
                  className="absolute -top-3 left-1/2 -translate-x-1/2"
                  data-testid="badge-most-popular"
                >
                  Most Popular
                </Badge>
              )}

              <div className="text-center mb-8">
                <h3 className="font-serif text-2xl md:text-3xl font-semibold text-foreground mb-2">
                  {tier.name}
                </h3>
                <div className="flex items-baseline justify-center gap-2 mb-1">
                  <span className="font-serif text-4xl md:text-5xl font-bold text-foreground">
                    {tier.price}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">{tier.period}</p>
              </div>

              <ul className="space-y-4 mb-8">
                {tier.features.map((feature, featureIndex) => (
                  <li
                    key={featureIndex}
                    className="flex items-start gap-3"
                    data-testid={`feature-${index}-${featureIndex}`}
                  >
                    <Check className="w-5 h-5 text-chart-2 flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className="w-full"
                variant={tier.popular ? "default" : "outline"}
                onClick={() => handleSelectPlan(tier.slug)}
                data-testid={`button-select-${tier.name.toLowerCase().replace(/\s+/g, "-")}`}
              >
                Select Plan
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
