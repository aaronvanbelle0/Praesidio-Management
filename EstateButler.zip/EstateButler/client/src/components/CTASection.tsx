import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

export default function CTASection() {
  const handleSchedule = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="py-24 md:py-32 bg-accent/10">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-6">
          Ready to Experience Praesidio Home Care?
        </h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          Schedule a complimentary consultation with our team to discuss your property management needs.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            size="lg"
            onClick={handleSchedule}
            className="text-base"
            data-testid="button-cta-schedule"
          >
            Schedule Consultation
          </Button>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Phone className="w-5 h-5" />
            <span className="text-lg font-medium" data-testid="text-phone">
              (555) 123-4567
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
