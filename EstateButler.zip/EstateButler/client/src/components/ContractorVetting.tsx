import { FileCheck, Shield, ClipboardCheck, Star } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function ContractorVetting() {
  const vettingSteps = [
    {
      icon: FileCheck,
      title: "Background Checks",
      description: "Comprehensive criminal background screening for every professional",
      requirements: [
        "National criminal database search",
        "Sex offender registry verification",
        "Identity verification",
        "Employment history validation"
      ]
    },
    {
      icon: Shield,
      title: "Licensing Verification",
      description: "Validation of all required professional licenses and certifications",
      requirements: [
        "State contractor license verification",
        "Specialized trade certifications",
        "Business license validation",
        "Regular renewal monitoring"
      ]
    },
    {
      icon: ClipboardCheck,
      title: "Insurance Requirements",
      description: "Mandatory comprehensive insurance coverage for all service providers",
      requirements: [
        "Minimum $2M general liability insurance",
        "Workers' compensation coverage",
        "Professional liability insurance",
        "Quarterly insurance verification"
      ]
    },
    {
      icon: Star,
      title: "Performance Reviews",
      description: "Ongoing quality monitoring and client satisfaction tracking",
      requirements: [
        "Client feedback after every service",
        "Quarterly performance evaluations",
        "Quality assurance spot checks",
        "Continuous improvement programs"
      ]
    }
  ];

  return (
    <section className="py-24 md:py-32 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-4" data-testid="text-vetting-heading">
            Our Rigorous Contractor Vetting Process
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-vetting-description">
            Only the top 5% of applicants join our network. Here's how we ensure excellence.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {vettingSteps.map((step, index) => (
            <Card
              key={index}
              className="p-8 hover-elevate transition-all duration-300"
              data-testid={`card-vetting-${step.title.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="flex items-start gap-4">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/20 flex-shrink-0">
                  <step.icon className="w-6 h-6 text-accent-foreground" />
                </div>
                <div className="flex-1">
                  <h3 
                    className="font-serif text-xl font-semibold text-foreground mb-2"
                    data-testid={`text-vetting-title-${step.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {step.title}
                  </h3>
                  <p 
                    className="text-muted-foreground mb-4 text-sm"
                    data-testid={`text-vetting-description-${step.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {step.description}
                  </p>
                  <ul className="space-y-2">
                    {step.requirements.map((req, idx) => (
                      <li 
                        key={idx} 
                        className="flex items-start gap-2 text-sm text-muted-foreground"
                        data-testid={`text-vetting-requirement-${step.title.toLowerCase().replace(/\s+/g, '-')}-${idx}`}
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0" />
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground max-w-3xl mx-auto" data-testid="text-vetting-assurance">
            Every contractor in our network is re-verified annually and subject to continuous performance monitoring. 
            We maintain a zero-tolerance policy for quality or safety violations.
          </p>
        </div>
      </div>
    </section>
  );
}
