import { Shield, CheckCircle, Umbrella } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function ServiceGuarantees() {
  const guarantees = [
    {
      icon: CheckCircle,
      title: "24/7 Response Guarantee",
      description: "We guarantee a response to your emergency requests within 24 hours, any time of day or night. If we don't meet this commitment, you receive a full refund of your monthly service fee—no questions asked.",
      details: [
        "Emergency response within 24 hours, guaranteed",
        "Full month refund if we miss our commitment",
        "Applies to all service tiers",
        "Available 365 days a year, including holidays"
      ]
    },
    {
      icon: Shield,
      title: "Quality Workmanship Guarantee",
      description: "Every service performed through Praesidio comes with our comprehensive quality guarantee. We stand behind the work of our vetted professionals.",
      details: [
        "30-day satisfaction guarantee on all completed work",
        "Free corrections for any quality issues",
        "Service warranty backed by our insurance",
        "Detailed photo documentation of all work"
      ]
    },
    {
      icon: Umbrella,
      title: "Damage & Liability Protection",
      description: "Complete peace of mind with comprehensive insurance coverage protecting your property and possessions during all service visits.",
      details: [
        "$2M general liability coverage on all contractors",
        "Workers' compensation for all service providers",
        "Property damage protection up to $1M",
        "Immediate claims processing within 24 hours"
      ]
    }
  ];

  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-foreground mb-4" data-testid="text-guarantees-heading">
            Our Service Guarantees
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-guarantees-description">
            Your trust matters. That's why we back every service with ironclad guarantees.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {guarantees.map((guarantee, index) => (
            <Card
              key={index}
              className="p-8 hover-elevate transition-all duration-300"
              data-testid={`card-guarantee-${guarantee.title.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/20 mb-6">
                <guarantee.icon className="w-8 h-8 text-accent-foreground" />
              </div>
              <h3 
                className="font-serif text-2xl font-semibold text-foreground mb-3"
                data-testid={`text-guarantee-title-${guarantee.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {guarantee.title}
              </h3>
              <p 
                className="text-muted-foreground leading-relaxed mb-6"
                data-testid={`text-guarantee-description-${guarantee.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {guarantee.description}
              </p>
              <ul className="space-y-2">
                {guarantee.details.map((detail, idx) => (
                  <li 
                    key={idx} 
                    className="flex items-start gap-2 text-sm text-muted-foreground"
                    data-testid={`text-guarantee-detail-${guarantee.title.toLowerCase().replace(/\s+/g, '-')}-${idx}`}
                  >
                    <CheckCircle className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
