import { useParams, useLocation } from "wouter";
import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check } from "lucide-react";

const tierData = {
  premium: {
    name: "Executive Management",
    price: "$8,000",
    period: "per year",
    description: "For discerning homeowners seeking proactive management of their property. We oversee maintenance, vendor coordination, and seasonal upkeep with the attention of a personal household manager—ensuring your home is always prepared, protected, and maintained to exacting standards.",
    features: [
      {
        category: "Included Services",
        items: [
          "Full coordination of home maintenance and repairs",
          "Management of vetted and insured vendors and tradesmen",
          "Vendor billing management and consolidated monthly statements",
          "Emergency response coordination and availability",
        ],
      },
      {
        category: "Complimentary Services (Quarterly)",
        items: [
          "Choice of one quarterly service:",
          "Deep cleaning",
          "Window washing",
          "Landscape refresh",
          "Gutter cleaning",
          "Pressure washing",
        ],
      },
      {
        category: "Additional Services (Preferred Member Rates)",
        items: [
          "Interior design and project coordination",
          "Seasonal décor setup or holiday preparation",
          "Post-storm inspections and readiness checks",
        ],
      },
      {
        category: "Ideal For",
        items: [
          "Primary or secondary homeowners who want reliable, year-round oversight and trusted service coordination without full-time staff involvement",
        ],
      },
    ],
  },
  executive: {
    name: "Executive Management",
    price: "$8,000",
    period: "per year",
    description: "For discerning homeowners seeking proactive management of their property. We oversee maintenance, vendor coordination, and seasonal upkeep with the attention of a personal household manager—ensuring your home is always prepared, protected, and maintained to exacting standards.",
    features: [
      {
        category: "Included Services",
        items: [
          "Full coordination of home maintenance and repairs",
          "Management of vetted and insured vendors and tradesmen",
          "Vendor billing management and consolidated monthly statements",
          "Emergency response coordination and availability",
        ],
      },
      {
        category: "Complimentary Services (Quarterly)",
        items: [
          "Choice of one quarterly service:",
          "Deep cleaning",
          "Window washing",
          "Landscape refresh",
          "Gutter cleaning",
          "Pressure washing",
        ],
      },
      {
        category: "Additional Services (Preferred Member Rates)",
        items: [
          "Interior design and project coordination",
          "Seasonal décor setup or holiday preparation",
          "Post-storm inspections and readiness checks",
        ],
      },
      {
        category: "Ideal For",
        items: [
          "Primary or secondary homeowners who want reliable, year-round oversight and trusted service coordination without full-time staff involvement",
        ],
      },
    ],
  },
  estate: {
    name: "Estate Concierge",
    price: "$35,000",
    period: "per year",
    description: "Complete peace of mind for luxury estates, secondary homes, and multiple properties. Estate Concierge members receive 24/7 access to Praesidio's dedicated management team and top-tier vendor network—so you can enjoy your properties worry-free while we handle every detail.",
    features: [
      {
        category: "Included Services",
        items: [
          "All Executive Management services",
          "24/7 direct contact and priority response",
          "Dedicated client manager for personalized oversight",
          "Preventative maintenance scheduling and tracking",
          "Multi-residence coordination and management",
        ],
      },
      {
        category: "Complimentary Services (Six Annually)",
        items: [
          "Choose from premium offerings such as:",
          "Deep cleaning or full interior/exterior window detailing",
          "Professional landscaping or seasonal property refresh",
          "Luxury vehicle detailing",
          "Annual property valuation and improvement report",
        ],
      },
      {
        category: "Additional Services (Available Upon Request)",
        items: [
          "Private event and gathering coordination",
          "Staff sourcing, background checks, and oversight",
          "Estate security and system evaluation",
        ],
      },
    ],
  },
};

export default function PlanDetails() {
  const params = useParams<{ tier: string }>();
  const [, setLocation] = useLocation();
  
  const tier = params.tier as keyof typeof tierData;
  const plan = tierData[tier];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [tier]);

  if (!plan) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="max-w-4xl mx-auto px-6 py-32 text-center">
          <h1 className="font-serif text-4xl font-semibold mb-4">Plan Not Found</h1>
          <p className="text-muted-foreground mb-8">The plan you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation("/")}>Return Home</Button>
        </div>
        <Footer />
      </div>
    );
  }

  const handleGetStarted = () => {
    const element = document.getElementById("contact");
    if (element) {
      setLocation("/#contact");
      setTimeout(() => {
        element.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      setLocation("/");
      setTimeout(() => {
        const contactElement = document.getElementById("contact");
        if (contactElement) {
          contactElement.scrollIntoView({ behavior: "smooth" });
        }
      }, 300);
    }
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <section className="pt-32 pb-16 bg-gradient-to-br from-accent/20 via-background to-muted/30">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="font-serif text-5xl md:text-6xl font-semibold text-foreground mb-4">
              {plan.name}
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              {plan.description}
            </p>
            <div className="flex items-baseline justify-center gap-2 mb-6">
              <span className="font-serif text-5xl md:text-6xl font-bold text-foreground">
                {plan.price}
              </span>
              <span className="text-lg text-muted-foreground">
                {plan.period}
              </span>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={handleGetStarted}
                data-testid="button-get-started-detail"
              >
                Get Started
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setLocation("/#pricing")}
                data-testid="button-compare-plans"
              >
                Compare All Plans
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-foreground mb-12 text-center">
            Complete Benefits & Features
          </h2>

          <div className="space-y-8">
            {plan.features.map((category, categoryIndex) => (
              <Card
                key={categoryIndex}
                className="p-8"
                data-testid={`category-${categoryIndex}`}
              >
                <h3 className="font-serif text-2xl font-semibold text-foreground mb-6">
                  {category.category}
                </h3>
                <ul className="space-y-4">
                  {category.items.map((item, itemIndex) => {
                    const noCheckItems = [
                      "Deep cleaning",
                      "Window washing",
                      "Landscape refresh",
                      "Gutter cleaning",
                      "Pressure washing"
                    ];
                    const showCheck = !noCheckItems.includes(item);
                    
                    return (
                      <li
                        key={itemIndex}
                        className="flex items-start gap-3"
                        data-testid={`feature-${categoryIndex}-${itemIndex}`}
                      >
                        {showCheck ? (
                          <Check className="w-6 h-6 text-chart-2 flex-shrink-0 mt-0.5" />
                        ) : (
                          <span className="w-6 h-6 flex-shrink-0" />
                        )}
                        <span className="text-foreground text-lg">{item}</span>
                      </li>
                    );
                  })}
                </ul>
              </Card>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Card className="p-8 bg-accent/10">
              <h3 className="font-serif text-2xl font-semibold text-foreground mb-4">
                Ready to Get Started?
              </h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Submit a service request and we'll contact you within 24 hours to discuss your specific needs and customize a plan that's perfect for your property.
              </p>
              <Button
                size="lg"
                onClick={handleGetStarted}
                data-testid="button-submit-request"
              >
                Submit Service Request
              </Button>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
